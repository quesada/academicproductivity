BRIEFLY
Thanks for downloading the Simplr theme. I hope it works for you.

LICENSE
The "Simplr" theme copyright (C) 2006 Scott Allan Wallick (http://scottwallick.com/) and distributed with a GNU General Public License, http://www.gnu.org/licenses/gpl.html.

INSTALLATION
For instructions and much, much more, visit http://www.plaintxt.org/themes/simplr/ 

IMPORTANT 
I strongly suggest visiting http://www.plaintxt.org/themes/simplr/ periodically as it is quite likely that I'll have caught some major flaw. Hopefully I'll get them all.

CREDITS
The lovely Mini Pixel Icons used in the comments form are from www.ndesign-studio.com. The feed icon is from http://www.feedicons.com. Also, many thanks go to Rick (http://www.mackrick.co.uk/) for giving me honest feedback and testing out this and other themes. 

# Scott
# http://www.plaintxt.org/
# http://scottwallick.com/
# http://www.welledited.com/