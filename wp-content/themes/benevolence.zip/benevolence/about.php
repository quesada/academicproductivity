<?php /*
       Template Name: About
       */
?>

<?php get_header(); ?>
<?php get_sidebar(); ?>
<br />
<div id="content">
   <div class="post">
	Type your content here
   </div> 
</div>
<br />
<?php get_footer(); ?>
