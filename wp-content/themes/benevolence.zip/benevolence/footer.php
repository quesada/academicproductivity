	</div>

<div id="footer">
<a class="footerLink" href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> is &copy; Author(s). 
<a class="footerLink" href="http://www.thoughtmechanics.com/blog/2005/01/03/benevolence/">Benevolence</a> theme by Theron Parlin.
<br />Syndicate entries using <a class="footerLink" href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">
   <?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a> and <a class="footerLink" href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>. This theme contains valid <a class="footerLink" href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('<abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a> and <a class="footerLink" href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>.
<br /><br /><br />
</div>

</div>

</body>
</html>
